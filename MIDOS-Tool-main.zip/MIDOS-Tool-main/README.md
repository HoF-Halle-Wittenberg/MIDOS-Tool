# MIDOS-Tool
Konvertiert MIDOS Dateiformat in RIS
